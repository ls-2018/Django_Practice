from .djdt_flamegraph import FlamegraphPanel
