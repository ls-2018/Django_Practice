"""
Welcome to django-autocomplete-light.

For examples, see the test_project/ directory of the repository.
"""
