"""QuerySetSequence choices for django-generic-m2m relations."""
