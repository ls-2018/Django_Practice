"""Empty module to look like a Django app."""
